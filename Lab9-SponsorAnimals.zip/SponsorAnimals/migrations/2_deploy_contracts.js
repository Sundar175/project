var Animals  = artifacts.require("./SponsorAnimals.sol");

module.exports = function(deployer) {
  deployer.deploy(Animals);
};
